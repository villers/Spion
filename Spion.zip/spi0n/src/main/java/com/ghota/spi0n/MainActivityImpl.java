package com.ghota.spi0n;

/**
 * Created by Ghota on 04/03/2014.
 */
public class MainActivityImpl extends MainActivity {
}
