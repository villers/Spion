package com.ghota.mydragtorefresh;

public interface RefreshableInterface {
	public void startFresh();
	public void startLoadMore();
}
